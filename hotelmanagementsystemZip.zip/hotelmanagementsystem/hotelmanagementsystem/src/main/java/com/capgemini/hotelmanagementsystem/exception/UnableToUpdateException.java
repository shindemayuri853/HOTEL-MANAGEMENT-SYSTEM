package com.capgemini.hotelmanagementsystem.exception;

public class UnableToUpdateException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
