package com.capgemini.hotelmanagementsystem.exception;

public class UnableRegisterException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
