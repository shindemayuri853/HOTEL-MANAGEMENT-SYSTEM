package com.capgemini.hotelmanagementsystem.util;

public class HotelManagementConstents {
	private HotelManagementConstents(){}
	
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
}
