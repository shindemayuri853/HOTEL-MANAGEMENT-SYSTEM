package com.capgemini.hotelmanagementsystem.exception;

//@SuppressWarnings("serial")
public class HotelManagementSystemException extends RuntimeException {
	
	//String message;
	
//	public HotelManagementSystemException(String message) {
//		super(message);
//	}
	private static final long serialVersionUID = 1L;
}
