package com.capgemini.hotelmanagementsystem.exception;

public class CancelBookingException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
