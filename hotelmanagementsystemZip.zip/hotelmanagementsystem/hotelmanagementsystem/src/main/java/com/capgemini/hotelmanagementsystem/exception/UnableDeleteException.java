package com.capgemini.hotelmanagementsystem.exception;

public class UnableDeleteException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
