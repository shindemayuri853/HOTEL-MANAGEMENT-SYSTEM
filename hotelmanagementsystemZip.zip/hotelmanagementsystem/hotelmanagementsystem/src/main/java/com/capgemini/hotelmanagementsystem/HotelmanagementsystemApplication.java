package com.capgemini.hotelmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelmanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelmanagementsystemApplication.class, args);
	}

}
