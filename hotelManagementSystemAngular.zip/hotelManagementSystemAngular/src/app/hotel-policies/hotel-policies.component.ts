import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotel-policies',
  templateUrl: './hotel-policies.component.html',
  styleUrls: ['./hotel-policies.component.css']
})
export class HotelPoliciesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
