import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-hotel-counter',
  templateUrl: './admin-hotel-counter.component.html',
  styleUrls: ['./admin-hotel-counter.component.css']
})
export class AdminHotelCounterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
