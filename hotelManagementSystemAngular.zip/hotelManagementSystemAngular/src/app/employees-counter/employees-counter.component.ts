import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employees-counter',
  templateUrl: './employees-counter.component.html',
  styleUrls: ['./employees-counter.component.css']
})
export class EmployeesCounterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
