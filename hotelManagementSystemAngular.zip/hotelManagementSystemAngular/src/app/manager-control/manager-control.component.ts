import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manager-control',
  templateUrl: './manager-control.component.html',
  styleUrls: ['./manager-control.component.css']
})
export class ManagerControlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
