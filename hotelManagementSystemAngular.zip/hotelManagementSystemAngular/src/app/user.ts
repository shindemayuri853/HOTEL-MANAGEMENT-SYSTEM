export class User {
    constructor(
        public userId: number,
        public userName: string,
        public emailId: string,
        public userType: string,
        public password: string
    ) { }
}
