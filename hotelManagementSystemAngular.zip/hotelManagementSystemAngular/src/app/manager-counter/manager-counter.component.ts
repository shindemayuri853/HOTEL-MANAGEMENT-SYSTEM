import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manager-counter',
  templateUrl: './manager-counter.component.html',
  styleUrls: ['./manager-counter.component.css']
})
export class ManagerCounterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
