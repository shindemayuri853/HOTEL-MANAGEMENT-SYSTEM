import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tariff-plan-facilities',
  templateUrl: './tariff-plan-facilities.component.html',
  styleUrls: ['./tariff-plan-facilities.component.css']
})
export class TariffPlanFacilitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
