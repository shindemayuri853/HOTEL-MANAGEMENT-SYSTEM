import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private route: Router) { }
  isUser() {
    const userDetails = JSON.parse(localStorage.getItem('user'));
    if (userDetails && userDetails.role === 'user') {
      return true;
    } else {
      return false;
    }
  }

  isAdmin() {
    const adminDetails = JSON.parse(localStorage.getItem('user'));
    if (adminDetails && adminDetails.role === 'admin') {
      return true;
    } else {
      return false;
    }
  }

  isLoggedIn() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
      return true;
    } else {
      return false;
    }
  }

  logout() {
    localStorage.removeItem('user');
    this.route.navigateByUrl('/login');
  }

  ngOnInit() {
  }

}
