import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  error: string = null;

  constructor(private auth: AuthService, private router: Router) { }
  register(registerForm: NgForm) {
    console.log(registerForm);
    this.auth.register(registerForm.value).subscribe(response => {
      console.log(response);
      if (response.statusCode === 201) {
        this.error = 'Registered Successfully';
       // this.router.navigateByUrl('/login');
      } else {
        this.error = 'Email Alredy Exist';
      }
      registerForm.reset();
    }, err => {
      console.log(err);
      this.error = err.error.message;
    });
  }
  ngOnInit() {
  }
}
