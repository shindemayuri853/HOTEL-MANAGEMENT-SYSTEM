import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
error: string = null;
  constructor(private authService: AuthService, private router: Router) {}
   submit(changePasswordForm: NgForm) {
     this.authService.changePassword(changePasswordForm.value).subscribe(res => {
       console.log(res);
       if (res.statusCode === 201) {
         this.error = 'Password Updated Successfully';
         changePasswordForm.reset();
         this.router.navigateByUrl('/login');
       }
     });
   }

  ngOnInit() {
  }

}
