import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
    providedIn: 'root'
})
export class AuthGuard implements CanActivate {
    constructor(private auth: AuthService) { }

    canActivate(route: ActivatedRouteSnapshot): boolean {
        const expectedRoleArray = route.data.expectedRole;
        const user = JSON.parse(localStorage.getItem('user'));
        // const admin = JSON.parse(localStorage.getItem('admin'));
        let expectedRole;
        for (const index in expectedRoleArray) {
            if (user && user.role === expectedRoleArray[index]) {
                expectedRole = expectedRoleArray[index];
            }
        }
        // if (user && user.type === expectedRole) {
        if (user && expectedRole === user.role) {
            return true;
        } else {
            return false;
        }
    }
}
