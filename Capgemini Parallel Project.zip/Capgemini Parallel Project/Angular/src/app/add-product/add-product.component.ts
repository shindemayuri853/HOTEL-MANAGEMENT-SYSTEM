import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  error: string = null;

  constructor(private productService: ProductService, private router: Router) { }
  addProduct(addProductForm: NgForm) {
    console.log(addProductForm.value);
    this.productService.addProduct(addProductForm.value).subscribe( res => {
      console.log(res);
      addProductForm.reset();
      this.router.navigateByUrl('/admin-product');
    }, err => {
      console.log(err);
      this.error = err.error.message;
    });
  }

  submit(addProductForm: NgForm) {
    this.router.navigateByUrl('/admin-product');
  }
  ngOnInit() {
  }

}
