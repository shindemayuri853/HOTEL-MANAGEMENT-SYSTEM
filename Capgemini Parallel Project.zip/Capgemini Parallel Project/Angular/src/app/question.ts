export class Discussion {
    constructor(
        public messageId: number,
        public userId: number,
        public question: string,
        public answer: string
    ) { }
}

