import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-disscussion',
  templateUrl: './disscussion.component.html',
  styleUrls: ['./disscussion.component.css']
})
export class DisscussionComponent implements OnInit {

  constructor(public discussionService: AuthService) {
    this.discussionService.discussionList();
   }

  ngOnInit() {
  }

}
