import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { ProductsComponent } from './products/products.component';
import { UserComponent } from './user/user.component';
import { AdminProductComponent } from './admin-product/admin-product.component';
import { AddProductComponent } from './add-product/add-product.component';
import { CartComponent } from './cart/cart.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AddtocartComponent } from './addtocart/addtocart.component';
import { DisscussionComponent } from './disscussion/disscussion.component';
import { AddquestionComponent } from './addquestion/addquestion.component';
import { GiveanswerComponent } from './giveanswer/giveanswer.component';
import { OrderhistoryComponent } from './orderhistory/orderhistory.component';
import { PaymentComponent } from './payment/payment.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    HeaderComponent,
    ProductsComponent,
    UserComponent,
    AdminProductComponent,
    AddProductComponent,
    CartComponent,
    ContactusComponent,
    AddtocartComponent,
    DisscussionComponent,
    AddquestionComponent,
    GiveanswerComponent,
    OrderhistoryComponent,
    PaymentComponent,
    PageNotFoundComponent,
    ChangepasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
