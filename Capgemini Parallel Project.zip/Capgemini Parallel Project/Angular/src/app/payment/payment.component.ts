import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
medicinePrice: number;
  constructor(public cartService: CartService, private router: Router) {
    this.cartService.payment().subscribe(response => {
      console.log(response);
      this.medicinePrice = response.price;
    });
   }

   payment(paymentForm: NgForm) {
     this.router.navigateByUrl('/orderhistory');
   }
  ngOnInit() {
  }

}
