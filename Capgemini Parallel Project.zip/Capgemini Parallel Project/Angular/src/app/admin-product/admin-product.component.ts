import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../product';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-admin-product',
  templateUrl: './admin-product.component.html',
  styleUrls: ['./admin-product.component.css']
})
export class AdminProductComponent implements OnInit {
  message: string = null;
  selectedProduct: Product = {
    productId: null,
    productName: null,
    category: null,
    price: null,
    quantity: null,
  };
  constructor(private productService: ProductService) {
    this.productService.getAllProducts();
  }
  // selectedProduct: Products = null;
  deleteProduct(product) {
    this.productService.deleteProduct(product).subscribe(response => {
      console.log(response);
      this.productService.getAllProducts();
      if (response.statusCode === 201) {
        this.message = 'Product Deleted Successfully';
      } else {
        this.message = 'Unable to Delete Product';
      }
    }, err => {
      console.log(err);
    });
  }

  selectProduct(product: Product) {
    this.selectedProduct = product;
  }
  submitForm(updateProduct: NgForm) {
    this.productService.updateProduct(updateProduct.value).subscribe(response => {
      console.log(response);
      updateProduct.reset();
    });
  }
  ngOnInit() {
  }

}
