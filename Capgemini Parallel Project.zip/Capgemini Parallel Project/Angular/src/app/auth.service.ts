import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  [x: string]: any;
  users = [];
  discussion = [];
  api = 'http://localhost:8080/';
  // http://localhost:8080/login?email=shinde@gmail.com&password=shinde98&role=user
  constructor(private http: HttpClient) { }
  login(loginData): Observable<any> {
    return this.http.get(`${this.api}login?email=${loginData.email}&password=${loginData.password}&role=${loginData.role}`, loginData);
  }

  register(registerData): Observable<any> {
    return this.http.put(`${this.api}register`, registerData);
  }
  getAllUsers() {
    this.http.get<any>(`${this.api}userList`).subscribe(user => {
      console.log(user);
      this.users = user.userist;
      console.log(this.users);
    });
  }
  // http://localhost:8080/deleteUser?id=4
  deleteUser(deleteUser): Observable<any> {
    return this.http.delete(`${this.api}deleteUser?id=${deleteUser.id}`, deleteUser);
  }

  isLogIn(): boolean {
    const user = JSON.parse(localStorage.getItem('token'));
    if (user && user.registered) {
      return true;
    } else {
      return false;
    }
  }

  discussionList() {
    this.http.get<any>(`${this.api}discussionTable`).subscribe(user => {
      console.log(user);
      this.discussion = user.discussionList;
      console.log(this.discussion);
    });
  }

  question(formData): Observable<any> {
      const data = {
        userId: JSON.parse(localStorage.getItem('user')).id,
        question: formData.question,
      };
      console.log(data);
      console.log(data.userId);
      return this.http.post<any>(`${this.api}question`, data);
    }

    answer(questionData): Observable<any> {
      return this.http.post<any>(`${this.api}answer?messageId=${questionData.messageId}&answer=${questionData.answer}`, questionData);
    }
    questionList() {
      this.http.get<any>(`${this.api}noAnsweredQuestions`).subscribe(user => {
        console.log(user);
        this.discussion = user.discussionList;
        console.log(this.discussion);
      });
    }

    // http://localhost:8080/passwordUpdate?email=an@gmail.com&password=Mayuri@123
    changePassword(data): Observable<any> {
     return this.http.post(`${this.api}passwordUpdate?email=${data.email}&password=${data.password}`, data);
    }
}
