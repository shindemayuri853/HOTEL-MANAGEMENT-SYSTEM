import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Discussion } from '../question';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-giveanswer',
  templateUrl: './giveanswer.component.html',
  styleUrls: ['./giveanswer.component.css']
})
export class GiveanswerComponent implements OnInit {
  selectedQuestion: Discussion = {
    messageId: null,
    userId: null,
    question: null,
    answer: null
  };

  constructor(public discussionService: AuthService) {
    this.discussionService.questionList();
   }
   giveResponse(giveanswer) {
     this.selectedQuestion = giveanswer;
    // console.log(giveanswer.value);
    // this.discussionService.question(giveanswer.value).subscribe(res => {
    //   console.log(res);
    //   giveanswer.reset();
    // }, err => {
    //   console.log(err);
    // });
  }
  submitForm(giveanswer: NgForm) {
    const data = {
      messageId: this.selectedQuestion.messageId,
      answer : giveanswer.value.answer
    };
    console.log(giveanswer.value);
    this.discussionService.answer(data).subscribe(res => {
        console.log(res);
        giveanswer.reset();
      }, err => {
        console.log(err);
      });
    }
  ngOnInit() {
  }

}
