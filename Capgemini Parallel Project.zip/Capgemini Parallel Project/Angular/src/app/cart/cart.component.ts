import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(public cartService: CartService) {
    this.cartService.cartProducts();
   }
   deletefromCart(cartProduct) {
    this.cartService.deleteProductCart(cartProduct).subscribe(response => {
      console.log(response);
      this.cartService.cartProducts();
    }, err => {
      console.log(err);
    });
   }
  ngOnInit() {
  }

}
