import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { ProductService } from '../product.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Product } from '../product';

@Component({
  selector: 'app-addtocart',
  templateUrl: './addtocart.component.html',
  styleUrls: ['./addtocart.component.css']
})
export class AddtocartComponent implements OnInit {
  error: string = null;

  constructor(public cartService: CartService, public productService: ProductService, private router: Router) {
    this.productService.getAllProducts();
  }

  submitForm(addcartProduct: NgForm) {
    this.cartService.selectedQuantity = addcartProduct.value.quantity;
    console.log(this.cartService.selectedQuantity);
    this.cartService.addToCart().subscribe(response => {
      console.log(response);
      addcartProduct.reset();
      if (response.statusCode === 201) {
        this.error = 'Product Added to Cart Successfully.';
      } else {
        this.error = 'Unable to Add Product';
      }
      // this.router.navigateByUrl('/cart');
    }, err => {
      console.log(err);
    });
  }

  addcart(product) {
    this.cartService.selectedProduct = product;
    console.log(this.cartService.selectedProduct);
  }
  ngOnInit() {
  }

}
