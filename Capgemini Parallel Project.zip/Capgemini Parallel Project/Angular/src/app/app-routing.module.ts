import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { ProductsComponent } from './products/products.component';
import { UserComponent } from './user/user.component';
import { AdminProductComponent } from './admin-product/admin-product.component';
import { AddProductComponent } from './add-product/add-product.component';
import { AuthGuard } from './auth.guard';
import { CartComponent } from './cart/cart.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AddtocartComponent } from './addtocart/addtocart.component';
import { DisscussionComponent } from './disscussion/disscussion.component';
import { AddquestionComponent } from './addquestion/addquestion.component';
import { GiveanswerComponent } from './giveanswer/giveanswer.component';
import { OrderhistoryComponent } from './orderhistory/orderhistory.component';
import { PaymentComponent } from './payment/payment.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';


const routes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'login', component: LoginComponent},
  {path: 'products', component: ProductsComponent},
  {path: 'user', component: UserComponent, canActivate: [AuthGuard] , data: {expectedRole: ['admin']}},
  {path: 'admin-product', component: AdminProductComponent, canActivate: [AuthGuard] , data: {expectedRole: ['admin']}},
  {path: 'add-product', component: AddProductComponent, canActivate: [AuthGuard] , data: {expectedRole: ['admin']} },
  {path: 'cart', component: CartComponent, canActivate: [AuthGuard], data: {expectedRole: ['user']}},
  {path: 'addtocart', component: AddtocartComponent, canActivate: [AuthGuard], data: {expectedRole: ['user']}},
  {path: 'contactus', component: ContactusComponent},
  {path: 'discussion', component: DisscussionComponent},
  {path: 'addquestion', component: AddquestionComponent, canActivate: [AuthGuard], data: {expectedRole : ['user']}},
  {path: 'giveanswer', component: GiveanswerComponent, canActivate: [AuthGuard] , data: {expectedRole: ['admin']}},
  {path: 'orderhistory', component: OrderhistoryComponent, canActivate: [AuthGuard] , data: {expectedRole: ['user']}},
  {path: 'payment', component: PaymentComponent},
  {path: 'changepassword', component: ChangepasswordComponent},
  {path: '**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
