import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  product: Product[] = [];
  api = 'http://localhost:8080/';
  constructor(private http: HttpClient) { }

  getAllProducts() {
    this.http.get<any>(`${this.api}getAllProducts`).subscribe(data => {
      console.log(data);
      this.product = data.productList;
      console.log(this.product);
    });
  }

  // http://localhost:8080/deleteProduct?productId=6
  deleteProduct(data): Observable<any> {
    return this.http.delete(`${this.api}deleteProduct?productId=${data.productId}`, data);
  }

  // http://localhost:8080/productUpdate?productId=1
  updateProduct(data): Observable<any> {
    return this.http.post(`${this.api}productUpdate`, data);
  }

  addProduct(data): Observable<any> {
    return this.http.post(`${this.api}productAdd`, data);
  }
  isProductAdded() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user && user.isProductAdded) {
      return true;
    } else {
      return false;
    }
  }
}
