import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { User } from '../user';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  selectedUser: User = {
    id: null,
    name: null,
    email: null,
    password: null
  };

  constructor(public userService: AuthService) {
    this.userService.getAllUsers();
  }

  deleteUser(user) {
    this.userService.deleteUser(user).subscribe(response => {
      console.log(response);
      this.userService.getAllUsers();
    }, (err: any) => {
      console.log(err);
    });
  }

  selectUser(user: User) {
    this.selectedUser = user;
  }
  ngOnInit() {
  }

}
