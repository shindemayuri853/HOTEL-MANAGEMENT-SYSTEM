import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-addquestion',
  templateUrl: './addquestion.component.html',
  styleUrls: ['./addquestion.component.css']
})
export class AddquestionComponent implements OnInit {
  message: string = null;

  constructor(public authService: AuthService) {
    this.authService.discussionList();
   }
   addQuestion(addQuestionForm: NgForm) {
     console.log(addQuestionForm.value);
     this.authService.question(addQuestionForm.value).subscribe(res => {
       console.log(res);
       addQuestionForm.reset();
       this.message = 'Thank you for your valuable time, we will Reply you soon';
     }, err => {
       console.log(err);
     });
   }

  ngOnInit() {
  }

}
