import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from './product';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  api = 'http://localhost:8080/';
  constructor(private http: HttpClient) { }
  selectedQuantity;
  selectedProduct: Product = {
    productId: null,
    productName: null,
    category: null,
    price: null,
    quantity: null
  };
  cart = [];
  price: number;
  // http://localhost:8080/addToCart?userId=2&productId=2&quantity=2
  addToCart(): Observable<any> {
    const data = {
      productId: this.selectedProduct.productId,
      userId: JSON.parse(localStorage.getItem('user')).id,
      quantity: this.selectedQuantity,
    };
    console.log(data);
    console.log(data.userId);
    console.log(data.quantity);
    return this.http.post<any>(`${this.api}addToCart?userId=${data.userId}&productId=${data.productId}&quantity=${data.quantity}`, data);
  }

  // http://localhost:8080/cartProducts?userId=2
  cartProducts() {
    const userId = JSON.parse(localStorage.getItem('user')).id;
    console.log(userId);
    this.http.get<any>(`${this.api}cartProducts?userId=${userId}`).subscribe(res => {
      console.log(res);
      this.cart = res.cartList;
      console.log(this.cart);
    });
  }

  // http://localhost:8080/deleteOneCart?orderId=2
  deleteProductCart(cart): Observable<any> {
    return this.http.delete(`${this.api}deleteOneCart?orderId=${cart.orderId}`, cart);
  }

  // http://localhost:8080/historyTable?userId=3
  orderHistory() {
    const userId = JSON.parse(localStorage.getItem('user')).id;
    console.log(userId);
    this.http.get<any>(`${this.api}historyTable?userId=${userId}`).subscribe(data => {
      console.log(data);
      this.cart = data.historyList;
      console.log(this.cart);
    });
  }
 // http://localhost:8080/payment?userId=1
 payment() {
  const userId = JSON.parse(localStorage.getItem('user')).id;
  console.log(userId);
  return this.http.get<any>(`${this.api}payment?userId=${userId}`);
}
}
